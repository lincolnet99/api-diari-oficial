﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;
using TBK_API_MODEL;

namespace TBK_API_DAO
{
    public class RegistroDAO : BaseDAO
    {

        public RegistroDAO(string _ConnectionString)
        {
            ConnectionString = _ConnectionString;
        }


        public string Cadastrar(RegistroModel Model)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("INSERT INTO TB_REGISTRO (ID_UF, VALOR_PUBLICO, VALOR_PRIVADO, TIPO_REGISTRO, DT_CRIACAO, OBSERVACAO, VALOR_TOTAL)" +
                    " VALUES ((SELECT ID FROM TB_UF WHERE UF = '{0}'), '{1}', '{2}', '{3}',{4},'{5}', '{6}')", Model.UF, Model.VALOR_PUBLICO, Model.VALOR_REGISTRADORA, Model.TIPO_REGISTRO, "GETDATE()", Model.OBSERVACAO, Model.VALOR_TOTAL);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();


                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        public List<RegistroModel> Listar(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                if (!String.IsNullOrEmpty(UF))
                    Pquery = string.Format("SELECT TB_U.UF, TB_R.* FROM TB_REGISTRO TB_R, TB_UF TB_U " +
                        "WHERE TB_R.ID_UF = TB_U.ID AND TB_U.UF = '{0}'", UF.ToUpper());
                else
                    Pquery = "SELECT TB_U.UF, TB_R.* FROM TB_REGISTRO TB_R, TB_UF TB_U WHERE TB_R.ID_UF = TB_U.ID";

                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    LstRegistro = new List<RegistroModel>();
                    while (rdr.Read())
                    {
                        objRegistro = new RegistroModel();

                        if (rdr["ID"] != DBNull.Value)
                            objRegistro.ID = Convert.ToInt32(rdr["ID"]);

                        if (rdr["ID_UF"] != DBNull.Value)
                            objRegistro.ID_UF = Convert.ToInt32(rdr["ID_UF"]);

                        if (rdr["UF"] != DBNull.Value)
                            objRegistro.UF = Convert.ToString(rdr["UF"]);

                        if (rdr["TIPO_REGISTRO"] != DBNull.Value)
                            objRegistro.TIPO_REGISTRO = Convert.ToString(rdr["TIPO_REGISTRO"]);

                        if (rdr["VALOR_PUBLICO"] != DBNull.Value)
                            objRegistro.VALOR_PUBLICO = Convert.ToString(rdr["VALOR_PUBLICO"]);

                        if (rdr["VALOR_PRIVADO"] != DBNull.Value)
                            objRegistro.VALOR_REGISTRADORA = Convert.ToString(rdr["VALOR_PRIVADO"]);

                        if (rdr["OBSERVACAO"] != DBNull.Value)
                            objRegistro.OBSERVACAO = Convert.ToString(rdr["OBSERVACAO"]);

                        if (rdr["DT_CRIACAO"] != DBNull.Value)
                            objRegistro.DT_CRIACAO = Convert.ToString(rdr["DT_CRIACAO"]);

                        if (rdr["VALOR_TOTAL"] != DBNull.Value)
                            objRegistro.VALOR_TOTAL = Convert.ToString(rdr["VALOR_TOTAL"]);

                        LstRegistro.Add(objRegistro);
                    }
                }

                SqlConn.Close();

                return LstRegistro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }

        public string Editar(RegistroModel Model)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                Pquery = "UPDATE TB_REGISTRO SET ID_UF = (SELECT ID FROM TB_UF WHERE UF = '" + Model.UF + "') ";

                string uf = " WHERE ID_UF = (SELECT ID FROM TB_UF WHERE UF = '" + Model.UF + "')";
                if (!String.IsNullOrEmpty(Model.VALOR_PUBLICO))
                    Pquery += " ,VALOR_PUBLICO = '" + Model.VALOR_PUBLICO + "'";

                if (!String.IsNullOrEmpty(Model.VALOR_TOTAL))
                    Pquery += " ,VALOR_TOTAL = '" + Model.VALOR_TOTAL + "'";

                if (!String.IsNullOrEmpty(Model.OBSERVACAO))
                    Pquery += " ,OBSERVACAO = '" + Model.OBSERVACAO + "'";

                if (!String.IsNullOrEmpty(Model.VALOR_REGISTRADORA))
                    Pquery += " ,VALOR_PRIVADO = '" + Model.VALOR_REGISTRADORA + "'";

                if (!String.IsNullOrEmpty(Model.TIPO_REGISTRO))
                    Pquery += " ,TIPO_REGISTRO = '" + Model.TIPO_REGISTRO + "'";


                SqlConn.Open();


                SqlCommand sqlCommand = new SqlCommand(Pquery + uf, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();


                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        public string Excluir(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("DELETE [dbo].[TB_REGISTRO] WHERE ID_UF IN (SELECT ID FROM [dbo].[TB_UF] WHERE UF = '{0}') ", UF);

                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();


                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

    }
}
