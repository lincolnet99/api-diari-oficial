﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;
using TBK_API_MODEL;

namespace TBK_API_DAO
{
    public class TipoNormativoDAO : BaseDAO
    {

		public TipoNormativoDAO(string _ConnectionString)
		{
			ConnectionString = _ConnectionString;
		}



		public List<TipoNormativoModel> Listar()
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();


                Pquery = "SELECT * FROM TB_TIPO_NORMATIVO";


                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    LstTipoNormativo = new List<TipoNormativoModel>();
                    while (rdr.Read())
                    {
                        LstTipoNormativo.Add(new TipoNormativoModel { Id = Convert.ToInt32(rdr["ID"]), Descricao = Convert.ToString(rdr["DESCRICAO"]) });
                    }
                }

                SqlConn.Close();

                return LstTipoNormativo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }
    }
}
