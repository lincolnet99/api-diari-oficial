﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;
using TBK_API_MODEL;

namespace TBK_API_DAO
{
    public class UFDAO : BaseDAO
    {
        public UFDAO(string _ConnectionString)
        {
            ConnectionString = _ConnectionString;

        }

        public List<UFModel> LstUf = null;
        public string Cadastrar(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                Pquery = string.Format("INSERT INTO TB_UF VALUES ('{0}')", UF.ToUpper());
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);

                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                return "OK";
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("UNIQUE KEY"))
                    throw new Exception("UF Já cadastrada!");
                else
                    throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }

        public List<UFModel> Listar(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                if (!String.IsNullOrEmpty(UF))
                    Pquery = string.Format(" SELECT * FROM TB_UF WHERE UF = '{0}' ", UF.ToUpper());
                else
                    Pquery = " SELECT * FROM TB_UF ";

                Pquery += " ORDER BY ID ASC";


                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();
                if (rdr != null && (rdr.HasRows))
                {
                    LstUf = new List<UFModel>();
                    while (rdr.Read())
                    {
                        LstUf.Add(new UFModel { Id = Convert.ToInt32(rdr["Id"]), UF = Convert.ToString(rdr["UF"].ToString()) });
                    }
                }

                SqlConn.Close();

                return LstUf;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }

        public List<UFModel> ListarUFRecentes()
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                Pquery = string.Format(" SELECT * FROM TB_UF WHERE ID IN(SELECT ID_UF FROM TB_NORMATIVO WHERE DT_CRIACAO BETWEEN GETDATE()-3 AND GETDATE()) ");



                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();
                if (rdr != null && (rdr.HasRows))
                {
                    LstUf = new List<UFModel>();
                    while (rdr.Read())
                    {
                        LstUf.Add(new UFModel { Id = Convert.ToInt32(rdr["Id"]), UF = Convert.ToString(rdr["UF"].ToString()) });
                    }
                }

                SqlConn.Close();

                return LstUf;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }
    }
}
