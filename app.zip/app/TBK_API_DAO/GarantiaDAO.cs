﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;
using TBK_API_MODEL;

namespace TBK_API_DAO
{
    public class GarantiaDAO : BaseDAO
    {

		public GarantiaDAO(string _ConnectionString)
		{
			ConnectionString = _ConnectionString;
		}


		public string Cadastrar(GarantiaModel Model)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("INSERT INTO TB_GARANTIA (ID_UF, VALOR_PUBLICO, VALOR_PRIVADO, TIPO_REGISTRO, DT_CRIACAO, OBSERVACAO, VALOR_TOTAL)" +
                    " VALUES ((SELECT ID FROM TB_UF WHERE UF = '{0}'), '{1}', '{2}', '{3}',{4},'{5}', '{6}')", Model.UF, Model.VALOR_PUBLICO, Model.VALOR_REGISTRADORA, Model.TIPO_REGISTRO, "GETDATE()",Model.OBSERVACAO, Model.VALOR_TOTAL);

                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();


                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        public List<GarantiaModel> Listar(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                if (!String.IsNullOrEmpty(UF))
                    Pquery = string.Format("SELECT TB_U.UF, TB_R.* FROM TB_GARANTIA TB_R, TB_UF TB_U " +
                        "WHERE TB_R.ID_UF = TB_U.ID AND TB_U.UF = '{0}'", UF.ToUpper());
                else
                    Pquery = "SELECT TB_U.UF, TB_R.* FROM TB_GARANTIA TB_R, TB_UF TB_U WHERE TB_R.ID_UF = TB_U.ID";

                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    LstGarantia = new List<GarantiaModel>();
                    while (rdr.Read())
                    {
                        objGarantia = new GarantiaModel();

                        if (rdr["ID"] != DBNull.Value)
                            objGarantia.ID = Convert.ToInt32(rdr["ID"]);

                        if (rdr["ID_UF"] != DBNull.Value)
                            objGarantia.ID_UF = Convert.ToInt32(rdr["ID_UF"]);

                        if (rdr["UF"] != DBNull.Value)
                            objGarantia.UF = Convert.ToString(rdr["UF"]);

                        if (rdr["TIPO_REGISTRO"] != DBNull.Value)
                            objGarantia.TIPO_REGISTRO = Convert.ToString(rdr["TIPO_REGISTRO"]);

                        if (rdr["VALOR_PUBLICO"] != DBNull.Value)
                            objGarantia.VALOR_PUBLICO = Convert.ToString(rdr["VALOR_PUBLICO"]);

                        if (rdr["VALOR_PRIVADO"] != DBNull.Value)
                            objGarantia.VALOR_REGISTRADORA = Convert.ToString(rdr["VALOR_PRIVADO"]);

                        if (rdr["OBSERVACAO"] != DBNull.Value)
                            objGarantia.OBSERVACAO = Convert.ToString(rdr["OBSERVACAO"]);

                        if (rdr["DT_CRIACAO"] != DBNull.Value)
                            objGarantia.DT_CRIACAO = Convert.ToString(rdr["DT_CRIACAO"]);

                        if (rdr["VALOR_TOTAL"] != DBNull.Value)
                            objGarantia.VALOR_TOTAL = Convert.ToString(rdr["VALOR_TOTAL"]);

                        LstGarantia.Add(objGarantia);
                    }
                }

                SqlConn.Close();

                return LstGarantia;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }


        public string Editar(GarantiaModel Model)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);
            try
            {
                Pquery = "UPDATE TB_GARANTIA SET ID_UF = (SELECT ID FROM TB_UF WHERE UF = '" + Model.UF + "') ";

                string uf = " WHERE ID_UF = (SELECT ID FROM TB_UF WHERE UF = '" + Model.UF + "')";
                if (!String.IsNullOrEmpty(Model.VALOR_PUBLICO))
                    Pquery += " ,VALOR_PUBLICO = '" + Model.VALOR_PUBLICO + "'";

                if (!String.IsNullOrEmpty(Model.VALOR_TOTAL))
                    Pquery += " ,VALOR_TOTAL = '" + Model.VALOR_TOTAL + "'";

                if (!String.IsNullOrEmpty(Model.OBSERVACAO))
                    Pquery += " ,OBSERVACAO = '" + Model.OBSERVACAO + "'";

                if (!String.IsNullOrEmpty(Model.VALOR_REGISTRADORA))
                    Pquery += " ,VALOR_PRIVADO = '" + Model.VALOR_REGISTRADORA + "'";

                if (!String.IsNullOrEmpty(Model.TIPO_REGISTRO))
                    Pquery += " ,TIPO_REGISTRO = '" + Model.TIPO_REGISTRO + "'";


                SqlConn.Open();


                SqlCommand sqlCommand = new SqlCommand(Pquery + uf, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();


                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        public string Excluir(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("DELETE [dbo].[TB_GARANTIA] WHERE ID_UF IN (SELECT ID FROM [dbo].[TB_UF] WHERE UF = '{0}') ", UF);

                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();


                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }


    }
}
