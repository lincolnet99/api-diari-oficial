﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;
using TBK_API_MODEL;

namespace TBK_API_DAO
{
    public class NormativoDAO : BaseDAO
    {
        public NormativoDAO(string _ConnectionString)
        {
            ConnectionString = _ConnectionString;
        }

        public string Cadastrar(NormativoModel Model)
        {
            if (Exists(Model))
                return "Normativo já cadastrado!";

            SqlConnection SqlConn = new SqlConnection(ConnectionString);
            try
            {
                SqlConn.Open();
                Pquery = string.Format("INSERT INTO TB_NORMATIVO VALUES ((SELECT ID FROM TB_UF WHERE UF = '{0}'), '{1}', '{2}', '{3}','{4}', GETDATE(), '{5}', '{6}')", Model.UF, Model.Nome_Portaria, Model.Nome_Arquivo, Model.Data_Vigencia, Model.Tipo_Normativo, Model.Tipo_Registro, Model.Nacional);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                if (!String.IsNullOrEmpty(Model.ArquivoB64))
                    CadastrarArquivo(Model.ArquivoB64);

                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        private string CadastrarArquivo(string ArquivoBase64)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("INSERT INTO TB_NORMATIVO_ARQUIVO VALUES ((SELECT TOP(1) ID FROM  TB_NORMATIVO ORDER BY ID DESC), '{0}', GETDATE())", ArquivoBase64);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        public List<NormativoModel> Listar(string UF)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                if (!String.IsNullOrEmpty(UF))
                    Pquery = string.Format(" SELECT TB_N.*, TB_U.UF\r\nFROM TB_NORMATIVO AS TB_N LEFT JOIN TB_UF AS TB_U ON TB_N.ID_UF = TB_U.ID " +
                        " WHERE TB_N.ID_UF = TB_U.ID AND TB_U.UF = '{0}'", UF.ToUpper());
                else
                    Pquery = "SELECT TB_N.*, TB_U.UF\r\nFROM TB_NORMATIVO AS TB_N LEFT JOIN TB_UF AS TB_U ON TB_N.ID_UF = TB_U.ID WHERE UF IS NULL";


                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    LstNormativo = new List<NormativoModel>();
                    while (rdr.Read())
                    {
                        objNormativo = new NormativoModel();

                        if (rdr["ID"] != DBNull.Value)
                            objNormativo.Id = Convert.ToInt32(rdr["ID"]);

                        if (rdr["ID_UF"] != DBNull.Value)
                            objNormativo.Id_UF = Convert.ToInt32(rdr["ID_UF"]);

                        if (rdr["UF"] != DBNull.Value)
                            objNormativo.UF = Convert.ToString(rdr["UF"]);

                        if (rdr["NOME_PORTARIA"] != DBNull.Value)
                            objNormativo.Nome_Portaria = Convert.ToString(rdr["NOME_PORTARIA"]);

                        if (rdr["NOME_ARQUIVO"] != DBNull.Value)
                            objNormativo.Nome_Arquivo = Convert.ToString(rdr["NOME_ARQUIVO"]);

                        if (rdr["DT_VIGENCIA"] != DBNull.Value)
                            objNormativo.Data_Vigencia = Convert.ToString(rdr["DT_VIGENCIA"]);

                        if (rdr["TIPO"] != DBNull.Value)
                            objNormativo.Tipo_Normativo = Convert.ToString(rdr["TIPO"]);


                        if (rdr["Tipo_Registro"] != DBNull.Value)
                            objNormativo.Tipo_Registro = Convert.ToString(rdr["Tipo_Registro"]);


                        if (rdr["NACIONAL"] != DBNull.Value)
                            objNormativo.Nacional = Convert.ToString(rdr["NACIONAL"]);

                        LstNormativo.Add(objNormativo);
                    }
                }

                SqlConn.Close();

                return LstNormativo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }

        public List<NormativoModel> ListarNacional()
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();


                Pquery = "SELECT TB_N.*, TB_U.UF FROM TB_NORMATIVO AS TB_N LEFT JOIN TB_UF AS TB_U ON TB_N.ID_UF = TB_U.ID WHERE (TB_N.NACIONAL = '1' OR TB_N.NACIONAL = 'S')";


                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    LstNormativo = new List<NormativoModel>();
                    while (rdr.Read())
                    {
                        objNormativo = new NormativoModel();

                        if (rdr["ID"] != DBNull.Value)
                            objNormativo.Id = Convert.ToInt32(rdr["ID"]);

                        if (rdr["ID_UF"] != DBNull.Value)
                            objNormativo.Id_UF = Convert.ToInt32(rdr["ID_UF"]);

                        if (rdr["UF"] != DBNull.Value)
                            objNormativo.UF = Convert.ToString(rdr["UF"]);

                        if (rdr["NOME_PORTARIA"] != DBNull.Value)
                            objNormativo.Nome_Portaria = Convert.ToString(rdr["NOME_PORTARIA"]);

                        if (rdr["NOME_ARQUIVO"] != DBNull.Value)
                            objNormativo.Nome_Arquivo = Convert.ToString(rdr["NOME_ARQUIVO"]);

                        if (rdr["DT_VIGENCIA"] != DBNull.Value)
                            objNormativo.Data_Vigencia = Convert.ToString(rdr["DT_VIGENCIA"]);

                        if (rdr["TIPO"] != DBNull.Value)
                            objNormativo.Tipo_Normativo = Convert.ToString(rdr["TIPO"]);


                        if (rdr["Tipo_Registro"] != DBNull.Value)
                            objNormativo.Tipo_Registro = Convert.ToString(rdr["Tipo_Registro"]);


                        if (rdr["NACIONAL"] != DBNull.Value)
                            objNormativo.Nacional = Convert.ToString(rdr["NACIONAL"]);

                        LstNormativo.Add(objNormativo);
                    }
                }

                SqlConn.Close();

                return LstNormativo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }

        }

        public string DownloadArquivoNormativo(string Id, string NomeArquivo, string NomeNormativo)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                if (!String.IsNullOrEmpty(Id))
                    Pquery = string.Format("SELECT top(1) ARQUIVO FROM TB_NORMATIVO_ARQUIVO" +
                        "WHERE ID_NORMATIVO  =  '{0}'", Id);

                else if (!String.IsNullOrEmpty(NomeArquivo))
                    Pquery = string.Format("SELECT TOP(1) ARQUIVO FROM TB_NORMATIVO_ARQUIVO " +
                 "WHERE ID_NORMATIVO  IN  (SELECT ID FROM TB_NORMATIVO WHERE NOME_ARQUIVO = '{0}')", NomeArquivo);


                else if (!String.IsNullOrEmpty(NomeNormativo))
                    Pquery = string.Format("SELECT TOP(1) ARQUIVO FROM TB_NORMATIVO_ARQUIVO " +
                 "WHERE ID_NORMATIVO  IN  (SELECT ID FROM TB_NORMATIVO WHERE NOME_PORTARIA = '{0}')", NomeNormativo);

                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    LstNormativo = new List<NormativoModel>();
                    while (rdr.Read())
                    {
                        ArquivoBase64 = Convert.ToString(rdr["ARQUIVO"]);
                    }
                }


                SqlConn.Close();

                return ArquivoBase64;
            }

            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Exists(NormativoModel Model)
        {

            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();

                Pquery = string.Format("SELECT * FROM [dbo].[TB_NORMATIVO] WHERE NOME_ARQUIVO = '{0}' AND ID_UF = (SELECT ID FROM  [dbo].[TB_UF] WHERE UF = '{1}') ", Model.Nome_Arquivo, Model.UF);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                SqlDataReader rdr = sqlCommand.ExecuteReader();

                if (rdr != null && (rdr.HasRows))
                {
                    while (rdr.Read())
                    {
                        _Exists = true;
                        break;
                    }
                }
                else
                    _Exists = false;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
            return _Exists;
        }

        public string Excluir(string Nome_Arquivo)
        {

            SqlConnection SqlConn = new SqlConnection(ConnectionString);
            try
            {
                SqlConn.Open();

                Pquery = string.Format("DELETE [dbo].[TB_NORMATIVO_ARQUIVO] WHERE ID_NORMATIVO IN (SELECT ID  FROM [dbo].[TB_NORMATIVO] WHERE NOME_ARQUIVO = '{0}')", Nome_Arquivo);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                SqlConn.Open();

                Pquery = string.Format("DELETE TB_NORMATIVO WHERE NOME_ARQUIVO = '{0}'", Nome_Arquivo);
                sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }


        public string Editar(NormativoModel Model)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            if (!Exists(Model))
                return "Normativo não encontrado, verifique o nome do Arquivo.";
            try
            {

                SqlConn.Open();

                Pquery = "UPDATE TB_NORMATIVO SET ID_UF = (SELECT ID FROM TB_UF WHERE UF = '" + Model.UF + "') ";
                string uf = " WHERE ID_UF = (SELECT ID FROM TB_UF WHERE UF = '" + Model.UF + "')";

                if (!String.IsNullOrEmpty(Model.Nome_Portaria))
                    Pquery += " ,NOME_PORTARIA = '" + Model.Nome_Portaria + "'";

                if (!String.IsNullOrEmpty(Model.Nacional))
                    Pquery += " ,NACIONAL = '" + Model.Nacional + "'";

                if (!String.IsNullOrEmpty(Model.Tipo_Registro))                    Pquery += " ,TIPO_REGISTRO = '" + Model.Tipo_Registro + "'";

                if (!String.IsNullOrEmpty(Model.Nome_Arquivo))
                    Pquery += " ,NOME_ARQUIVO = '" + Model.Nome_Arquivo + "'";



                SqlCommand sqlCommand = new SqlCommand(Pquery + uf, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                if (!String.IsNullOrEmpty(Model.ArquivoB64))
                    EditarArquivo(Model.ArquivoB64, Model.Nome_Arquivo);

                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

        private string EditarArquivo(string ArquivoBase64, string Nome_Arquivo)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("UPDATE TB_NORMATIVO_ARQUIVO SET ARQUIVO = '{0}', DT_CRIACAO = GETDATE() WHERE ID_NORMATIVO IN (SELECT TOP(1) ID FROM  TB_NORMATIVO WHERE NOME_ARQUIVO = '{1}' ORDER BY ID DESC) ", ArquivoBase64, Nome_Arquivo);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);
                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }
    }
}
