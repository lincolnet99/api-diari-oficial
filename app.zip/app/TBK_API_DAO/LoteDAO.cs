﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;

namespace TBK_API_DAO
{
    public class LoteDAO : BaseDAO
    {
        public LoteDAO(string _ConnectionString)
        {
            ConnectionString = _ConnectionString;

        }

        public string UploadLote(string NomeArquivo, string Base64)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                Pquery = string.Format("INSERT [dbo].[TB_LOTE] (Nome, Arquivo, DtUpload) VALUES ('{0}','{1}', GETDATE())", NomeArquivo, Base64);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);

                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();
                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

    }
}
