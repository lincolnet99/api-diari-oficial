﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_MODEL;

namespace TBK_API_DAO.Base
{
    public class BaseDAO
    {

        public string ConnectionString = "";
        public string Pquery = "";
        public List<UFModel> LstUf = null;
        public List<NormativoModel> LstNormativo = null;
        public NormativoModel objNormativo = null;
        public List<TipoNormativoModel> LstTipoNormativo = null;
        public string ArquivoBase64 = "";
        public List<RegistroModel> LstRegistro = null;
        public RegistroModel objRegistro = null;
        public List<GarantiaModel> LstGarantia = null;
        public GarantiaModel objGarantia = null;
        public bool _Exists;
    }

}
