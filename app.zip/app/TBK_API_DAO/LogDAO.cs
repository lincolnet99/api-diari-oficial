﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBK_API_DAO.Base;

namespace TBK_API_DAO
{
    public class LogDAO : BaseDAO
    {
        public LogDAO(string _ConnectionString)
        {
            ConnectionString = _ConnectionString;

        }

        public string Log(string MSG)
        {
            SqlConnection SqlConn = new SqlConnection(ConnectionString);

            try
            {
                SqlConn.Open();
                MSG = MSG.Replace(@"'", "-");
                Pquery = string.Format("INSERT INTO TB_LOG VALUES ('{0}', GETDATE())", MSG);
                SqlCommand sqlCommand = new SqlCommand(Pquery, SqlConn);

                sqlCommand.ExecuteNonQuery();
                SqlConn.Close();

                return "OK";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                SqlConn.Close();
            }
        }

    }
}
