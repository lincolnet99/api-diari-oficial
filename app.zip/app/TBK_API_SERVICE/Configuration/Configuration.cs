﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_SERVICE.Configuration
{
    public class Configuration
    {
        private readonly IConfiguration _configuration;

        public Configuration(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        public string GetConnection()
        {
            return _configuration.GetSection("ConnectionStrings").GetSection("PO27DataBase").Value;
        }
    }
}
