﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_SERVICE.Base
{
	public class BaseService
	{
		public string Connection = "";
		public string Path = "";

	}
}
