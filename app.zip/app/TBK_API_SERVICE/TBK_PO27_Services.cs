﻿using Microsoft.Extensions.Configuration;
using TBK_API_DAO;
using TBK_API_MODEL;
using TBK_API_SERVICE.Base;

namespace TBK_API_SERVICE
{
    public class TBK_PO27_Services : BaseService
    {
        private readonly IConfiguration _configuration;



        public TBK_PO27_Services(IConfiguration configuration)
        {
            _configuration = configuration;
            Connection = _configuration.GetSection("ConnectionStrings").GetSection("PO27DataBase").Value;
            Path = _configuration.GetSection("FileFolder").GetSection("Path").Value;
        }

        #region Cadastro

        public string CadastrarNormativo(string UF, string Nome_Portaria, string Nome_Arquivo, string Data_Vigencia, string Tipo, string Tipo_Registro, string ArquivoB64, string Nacional)
        {
            try
            {
                return new NormativoDAO(Connection).Cadastrar(new NormativoModel { Tipo_Normativo = Tipo, ArquivoB64 = ArquivoB64, Data_Vigencia = Data_Vigencia, Nome_Arquivo = Nome_Arquivo, Nome_Portaria = Nome_Portaria, UF = UF, Tipo_Registro = Tipo_Registro, Nacional = Nacional });
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public string CadastrarUF(string UF)
        {
            try
            {
                return new UFDAO(Connection).Cadastrar(UF);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public string CadastrarDadosRegistro(string UF, string ValorPublico, string ValorPrivado, string TipoRegistro, string Observacao, string ValorTotal)
        {
            try
            {
                var registro = new RegistroModel
                { UF = UF, TIPO_REGISTRO = TipoRegistro, VALOR_PUBLICO = ValorPublico, VALOR_REGISTRADORA = ValorPrivado, VALOR_TOTAL = ValorTotal, OBSERVACAO = Observacao};

                return new RegistroDAO(Connection).Cadastrar(registro);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }


        public string CadastrarDadosGarantia(string UF, string ValorPublico, string ValorPrivado, string TipoRegistro, string Observacao, string ValorTotal)
        {
            try
            {
                var Garantia = new GarantiaModel { UF = UF, TIPO_REGISTRO = TipoRegistro, VALOR_PUBLICO = ValorPublico, VALOR_REGISTRADORA = ValorPrivado, VALOR_TOTAL = ValorTotal, OBSERVACAO = Observacao };

                return new GarantiaDAO(Connection).Cadastrar(Garantia);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }


        public string UploadLote(string Nome_Arquivo,string ArquivoB64)
        {
            try
            {
                return new LoteDAO(Connection).UploadLote(Nome_Arquivo, ArquivoB64);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }



        #endregion

        #region Consulta

        public List<UFModel> ListarUF(string UF = "")
        {
            try
            {
                return new UFDAO(Connection).Listar(UF);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public List<UFModel> ListarUFRecentes()
        {
            try
            {
                return new UFDAO(Connection).ListarUFRecentes();
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public List<NormativoModel> ListarNormativo(string UF = "")
        {
            try
            {
                return new NormativoDAO(Connection).Listar(UF);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public List<TipoNormativoModel> ListarTipoNormativo()
        {
            try
            {
                return new TipoNormativoDAO(Connection).Listar();
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public string DownloadArquivoNormativo(string Id = "", string NomeArquivo = "", string NomeNormativo = "")
        {
            try
            {
                var Arquivo = new NormativoDAO(Connection).DownloadArquivoNormativo(Id, NomeArquivo, NomeNormativo);

                Path += NomeArquivo;

                if (!String.IsNullOrEmpty(Arquivo))
                    File.WriteAllBytes(Path, Convert.FromBase64String(Arquivo));

                return Path;
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }


        public List<RegistroModel> ListarDadosRegistro(string UF = "")
        {
            try
            {
                return new RegistroDAO(Connection).Listar(UF);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public List<GarantiaModel> ListarDadosGarantia(string UF = "")
        {
            try
            {
                return new GarantiaDAO(Connection).Listar(UF);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        public List<NormativoModel> ListarNacional()
        {
            try
            {
                return new NormativoDAO(Connection).ListarNacional();
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }




        #endregion


        #region Edição

        public string EditarDadosRegistro(string UF, string ValorPublico, string ValorPrivado, string TipoRegistro, string Observacao, string Valor_Total)
        {
            try
            {
                var registro = new RegistroModel
                {
                    UF = UF,
                    TIPO_REGISTRO = TipoRegistro,
                    VALOR_PUBLICO = ValorPublico,
                    VALOR_REGISTRADORA = ValorPrivado,
                    VALOR_TOTAL = Valor_Total,
                    OBSERVACAO = Observacao
                };

                return new RegistroDAO(Connection).Editar(registro);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public string EditarDadosGarantia(string UF, string ValorPublico, string ValorPrivado, string TipoRegistro, string Observacao, string Valor_Total)
        {
            try
            {
                var Garantia = new GarantiaModel
                {
                    UF = UF,
                    TIPO_REGISTRO = TipoRegistro,
                    VALOR_PUBLICO = ValorPublico,
                    VALOR_REGISTRADORA = ValorPrivado,
                    VALOR_TOTAL = Valor_Total,
                    OBSERVACAO = Observacao
                };


                return new GarantiaDAO(Connection).Editar(Garantia);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }


        public string EditarNormativo(string UF, string Nome_Portaria, string Nome_Arquivo, string Data_Vigencia, string Tipo, string Tipo_Registro, string ArquivoB64, string Nacional)
        {
            try
            {
                return new NormativoDAO(Connection).Editar(new NormativoModel { Tipo_Normativo = Tipo, ArquivoB64 = ArquivoB64, Data_Vigencia = Data_Vigencia, Nome_Arquivo = Nome_Arquivo, Nome_Portaria = Nome_Portaria, UF = UF, Tipo_Registro = Tipo_Registro, Nacional = Nacional });
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }



        #endregion

        #region Logs
        public string Log(Exception exception)
        {
            try
            {
                string msg = exception.Message + exception.InnerException;
                return new LogDAO(Connection).Log(msg);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        #endregion

        #region Excluir
        public string ExcluirNormativo(string Nome_Arquivo)
        {
            try
            {
                return new NormativoDAO(Connection).Excluir(Nome_Arquivo);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public string ExcluirDadosRegistro(string UF)
        {
            try
            {
                return new RegistroDAO(Connection).Excluir(UF);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }

        public string ExcluirDadosGarantia(string UF)
        {
            try
            {
                return new GarantiaDAO(Connection).Excluir(UF);
            }
            catch (Exception ex)
            {
                Log(ex);
                throw ex;
            }
        }



        #endregion

    }
}