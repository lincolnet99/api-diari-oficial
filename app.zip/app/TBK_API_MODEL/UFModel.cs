﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_MODEL
{
    public class UFModel
    {
        public int Id { get; set; }
        public string UF { get; set; }
    }
}
