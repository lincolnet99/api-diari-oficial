﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_MODEL
{
    public class NormativoModel
    {
        public int Id { get; set; }

        public int Id_UF { get; set; }

        public string UF { get; set; }
        public string Nome_Portaria { get; set; }
        public string Nome_Arquivo { get; set; }
        public string Data_Vigencia { get; set; }
        public string ArquivoB64 { get; set; }
        public string Tipo_Normativo { get; set; }

        public string Tipo_Registro { get; set; }
        public string Nacional { get; set; }
    }
}
