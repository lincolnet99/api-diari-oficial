﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_MODEL.Enum
{
    public enum TipoNormativoEnum
    {
        Registro_Contrato = 1,
        Registro_Garantia = 2,
        Cancelamento_Garantia = 3,
        Cadastro_Instituicao = 4,
        Outros = 5
    }
}
