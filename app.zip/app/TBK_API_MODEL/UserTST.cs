﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_MODEL
{
    public class UserTST
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "The user_id field is required.")]
        [JsonProperty("user_id")]
        public string? UserId { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Token aceita apenas numero")]
        [JsonProperty("Token")]
        [Range(0, int.MaxValue, ErrorMessage = "Entre apenas com Numero")]
        public string? Token { get; set; }

    }
}
