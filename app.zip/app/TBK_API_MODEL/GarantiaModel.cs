﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_MODEL
{
    public class GarantiaModel
    {
        public int ID { get; set; }
        public string UF { get; set; }
        public int ID_UF { get; set; }
        public string VALOR_PUBLICO { get; set; }
        public string VALOR_REGISTRADORA { get; set; }
        public string TIPO_REGISTRO { get; set; }
        public string DT_CRIACAO { get; set; }
        public string OBSERVACAO { get; set; }
        public string VALOR_TOTAL { get; set; }
    }
}
