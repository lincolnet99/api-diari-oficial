﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBK_API_MODEL
{
    public class TipoNormativoModel
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}

