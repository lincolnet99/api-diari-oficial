﻿using Microsoft.AspNetCore.Mvc;
using TBK_API_PO_27.Controllers;
using TBK_API_SERVICE;

namespace TBK_API_PO27.Controllers
{
    public class PO_27_EdicaoController : Controller
    {
        private string ArquivoBase64 = "";

        private readonly ILogger<PO_27_EdicaoController> _logger;
        private readonly IConfiguration _configuration;
        public PO_27_EdicaoController(ILogger<PO_27_EdicaoController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }


        [HttpPost]
        [Route("API/EditarDadosRegistro")]
        public ObjectResult EditarDadosRegistro(string UF, string TipoRegistro, string Taxa_Detran = "", string Valor_Registradora = "", string Observacao = "", string Valor_Total = "")
        {
            try
            {
                if (string.IsNullOrEmpty(UF))
                    return BadRequest("UF é obrigatória ");


                new TBK_PO27_Services(_configuration).EditarDadosRegistro(UF, Taxa_Detran, Valor_Registradora, TipoRegistro, Observacao, Valor_Total);
                return Ok("Dados do Registro Editados com Sucesso");

            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Editar Dados do Registro, causa: " + ex.Message);
            }
        }


        [HttpPost]
        [Route("API/EditarDadosGarantia")]
        public ObjectResult EditarDadosGarantia(string UF, string TipoRegistro, string Taxa_Detran = "", string Valor_Registradora = "", string Observacao = "", string Valor_Total = "")
        {
            try
            {
                if (string.IsNullOrEmpty(UF))
                    return BadRequest("UF é obrigatória ");


                new TBK_PO27_Services(_configuration).EditarDadosGarantia(UF, Taxa_Detran, Valor_Registradora, TipoRegistro, Observacao, Valor_Total);
                return Ok("Dados da Garantia Editados com Sucesso");

            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Editar Dados da Garantia, causa: " + ex.Message);
            }
        }




        [HttpPost]
        [Route("API/EditarNormativo")]
        public ObjectResult EditarNormativo(string Nome_Portaria, string Tipo_Normativo, string Tipo_Registro, IFormFile Arquivo, string UF = "", string Data_Vigencia = "", string Nacional = "")
        {
            try
            {

                if (string.IsNullOrEmpty(UF) )
                    return BadRequest("UF é obrigatória ");

                string Nome_Arquivo = "";
                if (string.IsNullOrEmpty(Nome_Arquivo) && Arquivo != null)
                    Nome_Arquivo = Arquivo.FileName;

                if (string.IsNullOrEmpty(Nome_Arquivo))
                    return BadRequest("Arquivo é obrigatório");

                else if (!Nome_Arquivo.ToUpper().Contains(".PDF") && !Nome_Arquivo.ToUpper().Contains(".TXT") && !Nome_Arquivo.ToUpper().Contains(".JPG") && !Nome_Arquivo.ToUpper().Contains(".JPEG") && !Nome_Arquivo.ToUpper().Contains(".DOC") && !Nome_Arquivo.ToUpper().Contains(".DOCX") && !Nome_Arquivo.ToUpper().Contains(".PPTX"))
                {
                    return BadRequest("Nome do Arquivo deve conter extensão: (Ex: .PDF, .JPG, .PPTX, .DOC, .DOCX");
                }
                else if (Nome_Arquivo.Contains(@"\") || Nome_Arquivo.Contains(@"/"))
                    return BadRequest(@"Nome do Arquivo não deve conter \ ou /");

                if (Arquivo.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        Arquivo.CopyTo(ms);
                        var fileBytes = ms.ToArray();
                        ArquivoBase64 = Convert.ToBase64String(fileBytes);

                    }
                }

                var ret = new TBK_PO27_Services(_configuration).EditarNormativo(UF, Nome_Portaria, Nome_Arquivo, Data_Vigencia, Tipo_Normativo, Tipo_Registro, ArquivoBase64, Nacional);

                if (ret == "OK")
                    return Ok("Normativo Editado com Sucesso");

                else return BadRequest(ret);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Editar Normativo, causa: " + ex.Message);
            }
        }

    }
}
