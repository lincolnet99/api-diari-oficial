﻿using Microsoft.AspNetCore.Mvc;
using TBK_API_PO_27.Controllers;
using TBK_API_SERVICE;

namespace TBK_API_PO27.Controllers
{
    [ApiController]
    public class PO_27_ExclusaoController : ControllerBase
    {
        private readonly ILogger<PO_27_ExclusaoController> _logger;
        private readonly IConfiguration _configuration;
        public PO_27_ExclusaoController(ILogger<PO_27_ExclusaoController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }


        [HttpPost]
        [Route("API/ExcluirNormativo")]
        public ObjectResult ExcluirNormativo(string Nome_Arquivo)
        {
            try
            {     
                if (string.IsNullOrEmpty(Nome_Arquivo))
                    return BadRequest(@"Nome do Arquivo é Obrigatório");
               
                var ret = new TBK_PO27_Services(_configuration).ExcluirNormativo(Nome_Arquivo);

                if (ret == "OK")
                    return Ok("Normativo Excluído com Sucesso");

                else return BadRequest(ret);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Excluír Normativo, causa: " + ex.Message);
            }
        }



        [HttpPost]
        [Route("API/ExcluirDadosRegistro")]
        public ObjectResult ExcluirDadosRegistro(string UF)
        {
            try
            {
                if (string.IsNullOrEmpty(UF))
                    return BadRequest(@"UF é Obrigatório");

                var ret = new TBK_PO27_Services(_configuration).ExcluirDadosRegistro(UF);

                if (ret == "OK")
                    return Ok("Dados Registro Excluído com Sucesso");

                else return BadRequest(ret);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Excluír Dados Registro, causa: " + ex.Message);
            }
        }


        [HttpPost]
        [Route("API/ExcluirDadosGarantia")]
        public ObjectResult ExcluirDadosGarantia(string UF)
        {
            try
            {
                if (string.IsNullOrEmpty(UF))
                    return BadRequest(@"UF é Obrigatório");

                var ret = new TBK_PO27_Services(_configuration).ExcluirDadosGarantia(UF);

                if (ret == "OK")
                    return Ok("Dados Garantia Excluído com Sucesso");

                else return BadRequest(ret);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Excluír Dados Garantia, causa: " + ex.Message);
            }
        }

    }
}
