﻿using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using TBK_API_MODEL;
using TBK_API_PO_27.Controllers;
using TBK_API_SERVICE;

namespace TBK_API_PO27.Controllers
{
    public class PO_27_ConsultaController : Controller
    {

        private readonly ILogger<PO_27_ConsultaController> _logger;
        private readonly IConfiguration _configuration;

        public PO_27_ConsultaController(ILogger<PO_27_ConsultaController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }


        [HttpGet]
        [Route("API/ListarUFRecentes")]
        public ObjectResult ListarUFRecentes()
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarUFRecentes();
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound(new List<UFModel>());

            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar UFs, causa: " + ex.Message);
            }
        }

        [HttpGet]
        [Route("API/ListarUF")]
        public ObjectResult ListarUF(string UF)
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarUF(UF);
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound("Dados não encontrados.");

            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar UFs, causa: " + ex.Message);
            }
        }


        [HttpGet]
        [Route("API/ListarNacional")]
        public ObjectResult ListarNacional()
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarNacional();
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound("Dados não encontrados.");

            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar normativos Nacionais, causa: " + ex.Message);
            }
        }



        [HttpGet]
        [Route("API/ListarNormativo")]
        public ObjectResult ListarNormativo(string UF)
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarNormativo(UF);
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound("Dados não encontrados.");
            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar Normativos, causa: " + ex.Message);
            }
        }


        [HttpGet]
        [Route("API/ListarTipoNormativo")]
        public ObjectResult ListarTipoNormativo()
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarTipoNormativo();
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound("Dados não encontrados.");
            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar Normativos, causa: " + ex.Message);
            }
        }


        [HttpGet]
        [SwaggerResponse((int)HttpStatusCode.OK, "Download a file.", typeof(FileContentResult))]
        [Route("API/DownloadNormativo")]
        public FileContentResult DownloadFile(string NomeArquivo)
        {
            try
            {
                if (String.IsNullOrEmpty(NomeArquivo))
                    throw new Exception("Nome do Arquivo é Obrigatório!");
                else
                {
                    var Path = new TBK_PO27_Services(_configuration).DownloadArquivoNormativo("", NomeArquivo, "");

                    return File(System.IO.File.ReadAllBytes(Path), "application/pdf", NomeArquivo);
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                throw ex;
            }
        }

        [HttpGet]
        [Route("API/ListarDadosRegistro")]
        public ObjectResult ListarDadosRegistro(string UF)
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarDadosRegistro(UF);
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound("Dados não encontrados.");
            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar Tipos Dados do Registro, causa: " + ex.Message);
            }
        }

        [HttpGet]
        [Route("API/ListarDadosGarantia")]
        public ObjectResult ListarDadosGarantia(string UF)
        {
            try
            {
                var lst = new TBK_PO27_Services(_configuration).ListarDadosGarantia(UF);
                if (lst != null)
                    return Ok(lst);
                else
                    return NotFound("Dados não encontrados.");
            }
            catch (Exception ex)
            {

                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Listar Tipos Dados do Registro, causa: " + ex.Message);
            }
        }
    }
}
