using Microsoft.AspNetCore.Mvc;
using System.Net;
using TBK_API_MODEL;
using TBK_API_SERVICE;
using TBK_API_SERVICE.Configuration;

namespace TBK_API_PO_27.Controllers
{
    [ApiController]
    public class PO_27_CadastroController : ControllerBase
    {
        private string ArquivoBase64 = "";
        private readonly ILogger<PO_27_CadastroController> _logger;
        private readonly IConfiguration _configuration;
        public PO_27_CadastroController(ILogger<PO_27_CadastroController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("API/CadastrarUF")]
        public ObjectResult CadastrarUF(string UF)
        {
            try
            {
                new TBK_PO27_Services(_configuration).CadastrarUF(UF);
                return Ok("UF Cadastrada com Sucesso");
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Cadastrar UF, causa: " + ex.Message);
            }
        }


        [HttpPost]
        [Route("API/CadastrarNormativo")]
        public ObjectResult CadastrarNormativo(string Nome_Portaria, string Tipo_Normativo, string Tipo_Registro, IFormFile Arquivo, string UF = "", string Data_Vigencia = "", string Nacional = "")
        {
            try
            {
                string Nome_Arquivo = "";
                if (string.IsNullOrEmpty(Nome_Arquivo))
                    Nome_Arquivo = Arquivo.FileName;
                else if (!Nome_Arquivo.ToUpper().Contains(".PDF") && !Nome_Arquivo.ToUpper().Contains(".TXT") && !Nome_Arquivo.ToUpper().Contains(".JPG") && !Nome_Arquivo.ToUpper().Contains(".JPEG") && !Nome_Arquivo.ToUpper().Contains(".DOC") && !Nome_Arquivo.ToUpper().Contains(".DOCX") && !Nome_Arquivo.ToUpper().Contains(".PPTX"))
                {
                    return BadRequest("Nome do Arquivo deve conter extens�o: (Ex: .PDF, .JPG, .PPTX, .DOC, .DOCX");
                }
                else if (Nome_Arquivo.Contains(@"\") || Nome_Arquivo.Contains(@"/"))
                    return BadRequest(@"Nome do Arquivo n�o deve conter \ ou /");

                if (Arquivo.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        Arquivo.CopyTo(ms);
                        var fileBytes = ms.ToArray();
                        ArquivoBase64 = Convert.ToBase64String(fileBytes);

                    }
                }

                var ret = new TBK_PO27_Services(_configuration).CadastrarNormativo(UF, Nome_Portaria, Nome_Arquivo, Data_Vigencia, Tipo_Normativo, Tipo_Registro, ArquivoBase64, Nacional);

                if (ret == "OK")
                    return Ok("Normativo Cadastrado com Sucesso");

                else return BadRequest(ret);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Cadastrar Normativo, causa: " + ex.Message);
            }
        }


        [HttpPost]
        [Route("API/CadastrarDadosRegistro")]
        public ObjectResult CadastrarDadosRegistro(string UF, string TipoRegistro, string Taxa_Detran = "", string Valor_Registradora = "", string Observacao = "", string ValorTotal = "")
        {
            try
            {
                new TBK_PO27_Services(_configuration).CadastrarDadosRegistro(UF, Taxa_Detran, Valor_Registradora, TipoRegistro, Observacao, ValorTotal);
                return Ok("Dados do Registro Cadastrados com Sucesso");

            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Cadastrar Dados do Registro, causa: " + ex.Message);
            }
        }


        [HttpPost]
        [Route("API/CadastrarDadosGarantia")]
        public ObjectResult CadastrarDadosGarantia(string UF, string TipoRegistro, string Taxa_Detran = "", string Valor_Registradora = "", string Observacao = "", string ValorTotal = "")
        {
            try
            {
                new TBK_PO27_Services(_configuration).CadastrarDadosGarantia(UF, Taxa_Detran, Valor_Registradora, TipoRegistro, Observacao, ValorTotal);
                return Ok("Dados da Garantia Cadastrados com Sucesso");

            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro ao Cadastrar Dados da Garantia, causa: " + ex.Message);
            }
        }



        [HttpPost]
        [Route("API/UploadLote")]
        public ObjectResult UploadLote(IFormFile Arquivo)
        {
            try
            {
                string Nome_Arquivo = Arquivo.FileName;

                if (!Nome_Arquivo.ToUpper().Contains(".XLS") && !Nome_Arquivo.ToUpper().Contains(".XLSX"))
                {
                    return BadRequest("Nome do Arquivo deve conter extens�o: (.XLS, .XLSX");
                }
                else if (Nome_Arquivo.Contains(@"\") || Nome_Arquivo.Contains(@"/"))
                    return BadRequest(@"Nome do Arquivo n�o deve conter \ ou /");

                if (Arquivo.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        Arquivo.CopyTo(ms);
                        var fileBytes = ms.ToArray();
                        ArquivoBase64 = Convert.ToBase64String(fileBytes);

                    }
                }

                var ret = new TBK_PO27_Services(_configuration).UploadLote(Nome_Arquivo, ArquivoBase64);

                if (ret == "OK")
                    return Ok("Upload do Lote, realizado com sucesso!");

                else return BadRequest(ret);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest("Erro realizar Upload, causa: " + ex.Message);
            }
        }


    }
}